Magento patch SUPEE-8788
Refer to https://magentary.com/kb/install-supee-8788-without-ssh/ for installation instructions.
